#!/usr/bin/env python

#########################################################################################################
#Import the required libraries:
import rospy
from geometry_msgs.msg import Twist,Pose
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import numpy as np
import math
import sympy as sym
from sympy import *

rospy.init_node('path_planning', anonymous=True) #Identify ROS Node

desiredPos_publisher = rospy.Publisher('desiredPose', Twist, queue_size=1) #Identify the publisher "pub1" to publish on topic "/APF_Des_Pos" to send message of type "Pose"
desiredVel_publisher = rospy.Publisher('desiredVel', Twist, queue_size=1)
Des_Pos_msg = Pose() #Identify msg variable of data type Twist
rate = rospy.Rate(100) # rate of publishing msg 10hz

path=[[0,0],[2,2],[10,4],[20,2],[22,0],[24,-2],[28,-4],[45,-4],[48,-2],[52,0],[54,2],[56,4],[70,4]]

i=0
xPos=0
yPos=0
yaw=0
curPos=[0,0]
curSpeed=0.0001
desVel=0
omegaZ=0
distance=0
stop=False

def euler_to_quaternion(yaw, pitch, roll):
    x = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    y = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
    z = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
    w = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    return [x, y, z, w]

def quaternion_to_euler(x, y, z, w):
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch = math.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(t3, t4)
    return [yaw, pitch, roll]

def callback_speed(msg):
    global curSpeed
    global omegaZ

    curSpeed=round(msg.twist.linear.x,3)
    omegaZ=round(msg.twist.angular.z,3)

def callback_pose(msg):
    global xPos
    global yPos
    global yaw
    global flag_cont
    flag_cont=1
    xPos=round(msg.pose.pose.position.x,3)
    yPos=round(msg.pose.pose.position.y,3)
    [yaw,_,_]=quaternion_to_euler(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,msg.pose.pose.orientation.z,msg.pose.pose.orientation.w)

def _subscriber():
    subPosOri = rospy.Subscriber('odom', Odometry, callback_pose)

def _publisher():
    Total_time = 50000 #total time of simulation
    Ts = 0.1 #sampling time
    Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps

    for t in Time:
     curPos=[xPos,yPos]
     desPoint=path[i]
     distance = math.sqrt((desPoint[0]-curPos[0])**2 + (desPoint[1]-curPos[1])**2)

     if distance<2 and i<len(path):
      i+=1
     
     if i>len(path):
      stop=True
      
     if(not stop): 
      if distance>2:
          desVel=distance*0.3
      else:
          desVel=distance*0.5
     else:
         desVel=0
     
     Des_Pos_msg.position.x = desPoint[0]
     Des_Pos_msg.position.y = desPoint[1]
     pub1.publish(Des_Pos_msg)	#Publish msg
     pub2.publish(desVel)

if __name__ == '__main__':
    try:
        actual_subscriber()
        actualPose_publisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass