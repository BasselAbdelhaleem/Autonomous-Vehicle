#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist, Pose
import numpy as np
import math

xDes = 0
yDes = 0
xAct = 0
yAct = 0
heading = 0
steeringAngle = 0
curSpeed = 0.0001
prevPoint = [0, 0]

steerLimit = 30 * (math.pi / 180)  # degrees to radians
K = 1500  # control gain

def actual_callback(msg):
    global curSpeed, heading
    curSpeed = msg.linear.x
    heading = msg.angular.z * (math.pi / 180)  # Convert to radians

def actualPos_callback(msg):
    global xAct, yAct
    xAct = msg.linear.x
    yAct = msg.linear.y

def desiredPos_callback(msg):
    global xDes, yDes
    xDes = msg.position.x
    yDes = msg.position.y

def stanley_control():
    global xDes, yDes, xAct, yAct, heading, curSpeed, prevPoint, steeringAngle

    desPoint = [xDes, yDes]
    curPose = [xAct, yAct]

    e_numerator = (desPoint[0] - prevPoint[0]) * (prevPoint[1] - curPose[1]) - (prevPoint[0] - curPose[0]) * (desPoint[1] - prevPoint[1])
    e_denominator = math.sqrt((desPoint[0] - prevPoint[0]) ** 2 + (desPoint[1] - prevPoint[1]) ** 2)
    
    if e_denominator != 0:
        e = e_numerator / e_denominator
    else:
        e = 0

    desAngle = math.atan2(desPoint[1] - prevPoint[1], desPoint[0] - prevPoint[0])
    errorAngle = desAngle - heading

    if abs(curSpeed) > 0:
        steeringAngle = round(errorAngle + np.arctan((K * e) / curSpeed), 3)

    steeringAngle = max(min(steeringAngle, steerLimit), -steerLimit)
    prevPoint = curPose
    
    return steeringAngle * (180 / math.pi)  # Convert back to degrees for publishing

if __name__ == '__main__':
    rospy.init_node('lateral_control', anonymous=True)

    rospy.Subscriber('actual', Twist, actual_callback)
    rospy.Subscriber('actualPose', Twist, actualPos_callback)
    rospy.Subscriber('desiredPose', Pose, desiredPos_callback)

    desiredAngle_pub = rospy.Publisher('desired', Twist, queue_size=1)

    rate = rospy.Rate(100)  # 100 Hz

    while not rospy.is_shutdown():
        msg = Twist()
        msg.angular.z = stanley_control()
        desiredAngle_pub.publish(msg)
        rate.sleep()