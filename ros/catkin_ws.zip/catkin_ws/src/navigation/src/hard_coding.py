#! /usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from pynput import keyboard
import numpy as np
from geometry_msgs.msg import Twist
import math
import time

velArray = [255, 255, 255, 255, 100, 100, 100, 100, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255]
angArray = [0, 0, 0, 0, 0, 30, 30, 30, 30, -30, -30, -30, 0, 0, 0, 0, 0, 0, 0, 0]
timeArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
t = time.time()
vel = 0
ang = 0

rospy.init_node('hard_coding', anonymous=True)

vel_pub = rospy.Publisher('desired', Twist, queue_size=1)

if __name__ == '__main__':
    try:
        while not rospy.is_shutdown():
            for i in range(len(timeArray)):
                r = time.time()-t
                vel_msg = Twist()
                if int(r) == timeArray[i]:
                    vel = velArray[i]
                    ang = angArray[i]
                
                vel_msg.linear.x = vel
                vel_msg.angular.z = ang
                
                vel_pub.publish(vel_msg)
    except rospy.ROSInterruptException:
        pass