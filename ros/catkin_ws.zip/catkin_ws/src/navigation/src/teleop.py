#! /usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from geometry_msgs.msg import Twist
from pynput import keyboard
import numpy as np

# Initialize the ROS node
rospy.init_node('desired_publisher', anonymous=True)

# Create a publisher for the '/cmd_vel' topic with the message type Twist
desired_pub = rospy.Publisher('desired', Twist, queue_size=10)

# Initial velocity and steering angle
velocityDes = 0
angleDes = 0

def drive_forward():
    if not rospy.is_shutdown():
        global velocityDes
        velocityDes += 1
        desired_publisher()

def drive_reverse():
    if not rospy.is_shutdown():
        global velocityDes
        velocityDes -= 1
        desired_publisher()
 
def steer_left():
    if not rospy.is_shutdown():
        global angleDes
        angleDes = 120
        desired_publisher()

def steer_right():
    if not rospy.is_shutdown():
        global angleDes
        angleDes = 65
        desired_publisher()

def steer_center():
    if not rospy.is_shutdown():
        global angleDes
        angleDes = 0
        desired_publisher()
    
def stop():
    if not rospy.is_shutdown():
        global velocityDes
        global angleDes
        velocityDes = 0
        angleDes = 0
        desired_publisher()

def desired_publisher():
    # Set the loop rate (in Hz)
    rate = rospy.Rate(100)  # 100 Hz
    
    # Create a Twist message
    vel_msg = Twist()
    vel_msg.linear.x = velocityDes  # Set linear velocity to 0.5 m/s
    vel_msg.angular.z = angleDes  # Set angular velocity to 0.1 rad/s

    # Publish the Twist message
    desired_pub.publish(vel_msg)
    rate.sleep()

def on_press(key):
    if key == keyboard.Key.up:
        print("forward")
        drive_forward()
    if key == keyboard.Key.down:
        print("backward")
        drive_reverse()
    if key == keyboard.Key.left:
        print("left")
        steer_left()
    if key == keyboard.Key.right:
        print("right")
        steer_right()
    if key == keyboard.Key.space:
        print("stop")
        stop()
    if key == keyboard.Key.esc:
        print("quit")
        listener.stop()

def on_release(key):
    steer_center()

with keyboard.Listener(on_press=on_press,on_release=on_release) as listener:
    listener.join()