#! /usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from pynput import keyboard
import numpy as np
from geometry_msgs.msg import Twist

driving = 50
steering = 120

def velocity_publisher():
    # Initialize the ROS node
    rospy.init_node('velocity_publisher', anonymous=True)

    # Create a publisher for the '/cmd_vel' topic with the message type Twist
    velocity_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)

    # Set the loop rate (in Hz)
    rate = rospy.Rate(1)  # 1 Hz

    # Create a Twist message
    vel_msg = Twist()
    vel_msg.linear.x = driving  # Set linear velocity to 0.5 m/s
    vel_msg.angular.z = steering  # Set angular velocity to 0.1 rad/s

    # Publish the Twist message repeatedly
    while not rospy.is_shutdown():
        velocity_pub.publish(vel_msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        velocity_publisher()
    except rospy.ROSInterruptException:
        pass
