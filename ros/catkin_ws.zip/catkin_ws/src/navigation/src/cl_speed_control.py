#! /usr/bin/env python3

import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from pynput import keyboard
import numpy as np
from geometry_msgs.msg import Twist
import math
import time

desired_velocity = 100
actual_velocity = 0

#wheelRadius = 0.13

Kp = 3.4
Kd = 0.03
Ki = 0.1
KiRun = Ki
previous_error = 0
integral = 0
errorLimit = 40
ts = 0

def pid_control(target_value, current_value):
    global previous_error, integral, Kp, Ki, KiRun, Kd, ts
    
    tsNew = time.time()
    r = tsNew - ts
        
    error = target_value - current_value
    derivative = (error - previous_error)/r
    integral += error*r
    
    if abs(error) > errorLimit:
        KiRun = 0
        integral = 0
    else:
        KiRun = Ki
        
    if current_value == 0:
        integral = 0
    
    pwm = Kp * error + KiRun * integral + Kd * derivative
    if pwm > 255:
        pwm = 255
    if pwm < -255:
        pwm = -255
    
    previous_error = error
    ts = tsNew

    return pwm

def actual_callback(msg):
    global velocity_actual
    # Callback function to handle incoming velocity messages
    velocity_actual = msg.linear.x
    
def actual_subscriber():
    rospy.Subscriber('actual', Twist, actual_callback)

def velocity_publisher():
    # Initialize the ROS node
    rospy.init_node('velocity_publisher', anonymous=True)

    # Create a publisher for the '/cmd_vel' topic with the message type Twist
    velocity_pub = rospy.Publisher('desired', Twist, queue_size=1)

    # Set the loop rate (in Hz)
    rate = rospy.Rate(1)  # 1 Hz

    # Publish the Twist message repeatedly
    while not rospy.is_shutdown():
        # Create a Twist message
        vel_msg = Twist()
        vel_msg.linear.x = pid_control(desired_velocity, actual_velocity)  # Set pwm as pid control output
        velocity_pub.publish(vel_msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        velocity_publisher()
        actual_subscriber()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass