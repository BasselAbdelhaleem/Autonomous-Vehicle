#! /usr/bin/env python3

import serial
import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from pynput import keyboard
import numpy as np
from geometry_msgs.msg import Twist

# Define the port and baud rate (change this according to your system)
port = '/dev/ttyACM1'  # or whatever your serial port is
baud_rate = 115200 # or whatever baud rate your device uses

# Open the serial port
ser = serial.Serial(port, baud_rate, timeout=1)

def desired_callback(msg):
    if not rospy.is_shutdown():
        # Callback function to handle incoming velocity messages
        velocityDes = msg.linear.x
        angleDes = msg.angular.z
        rospy.loginfo("Received linear velocity: {}, angular velocity: {}".format(velocityDes, angleDes))
        output = str(velocityDes) + "/" + str(angleDes) + "\n"
        print(output)
        ser.write(output.encode())
    
def desired_subscriber():
    # Initialize the ROS node
    rospy.init_node('desired_subscriber', anonymous=True)
    # Subscribe to the '/cmd_vel' topic which publishes velocity commands
    rospy.Subscriber('desired', Twist, desired_callback)
    # Spin to prevent exiting until the node is stopped manually
    rospy.spin()
    
if __name__ == '__main__':
    try:
        desired_subscriber()
    except rospy.ROSInterruptException:
        pass