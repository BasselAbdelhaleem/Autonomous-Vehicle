#! /usr/bin/env python3

import serial
import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from pynput import keyboard
import numpy as np
from geometry_msgs.msg import Twist

# Define the port and baud rate (change this according to your system)
port = '/dev/ttyUSB0'  # or whatever your serial port is
baud_rate = 115200 # or whatever baud rate your device uses

# Open the serial port
ser = serial.Serial(port, baud_rate, timeout=1)

def actual_publisher():
    # Initialize the ROS node
    rospy.init_node('actual_publisher', anonymous=True)

    # Create a publisher for the '/cmd_vel' topic with the message type Twist
    actual_pub = rospy.Publisher('actual', Twist, queue_size=1)

    # Set the loop rate (in Hz)
    rate = rospy.Rate(100)  # 100 Hz
    
    while not rospy.is_shutdown():
        dataAct = ser.readline().decode()
        dataSplit = dataAct.split("/")
        #print(dataSplit)
        try:
            velocityAct = dataSplit[0]
            angleAct = dataSplit[1].split("\n")[0]
            print(velocityAct, angleAct)
        except:
            velocityAct = -999
            angleAct = -999
        
    
        # Create a Twist message
        vel_msg = Twist()
        vel_msg.linear.x = int(velocityAct)  # Set linear velocity to 0.5 m/s
        vel_msg.angular.z = int(angleAct)  # Set angular velocity to 0.1 rad/s

        # Publish the Twist message
        actual_pub.publish(vel_msg)
        rate.sleep()
    
if __name__ == '__main__':
    try:
        actual_publisher()
    except rospy.ROSInterruptException:
        pass