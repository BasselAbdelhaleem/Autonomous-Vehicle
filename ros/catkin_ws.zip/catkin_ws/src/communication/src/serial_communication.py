#! /usr/bin/env python3

import serial
import rospy
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from pynput import keyboard
import numpy as np
from geometry_msgs.msg import Twist

wheelRadius = 0.13

velocityAct = 0.0
angleAct = 0.0

# Define the port and baud rate (change this according to your system)
nanoReceivePort = '/dev/ttyACM0'  # or whatever your serial port is
UnoSendPort = '/dev/ttyACM1'
baud_rate = 115200 # or whatever baud rate your device uses

# Open the serial ports
nanoReceiveSerial = serial.Serial(nanoReceivePort, baud_rate, timeout=0.5) # actual angle
UnoSendSerial = serial.Serial(UnoSendPort, baud_rate, timeout=0.5) # desired velocity & angle

rospy.init_node('serial_communication', anonymous=True)

# Set the loop rate (in Hz)
rate = rospy.Rate(100)  # 100 Hz
    
def desired_callback(msg):
    if not rospy.is_shutdown():
        velocityDes = msg.linear.x
        angleDes = msg.angular.z
        rospy.loginfo("Received linear velocity: {}, angular velocity: {}".format(velocityDes, angleDes))
        output = str(velocityDes) + "/" + str(angleDes) + "\n"
        #print(output)
        UnoSendSerial.write(output.encode())

def desired_subscriber():
    rospy.Subscriber('desired', Twist, desired_callback)
    
def actual_publisher():
    global velocityAct, angleAct
    #rospy.init_node('actual_publisher', anonymous=True)

    # Create a publisher for the '/cmd_vel' topic with the message type Twist
    actual_pub = rospy.Publisher('actual', Twist, queue_size=1)
    
    while not rospy.is_shutdown():
        dataAct = nanoReceiveSerial.readline().decode()
        dataSplit = dataAct.split("/")
        #print(dataSplit)
        try:
            velocityAct = dataSplit[0]
            angleAct = dataSplit[1].split("\n")[0]
            print(velocityAct, angleAct)
        except:
            velocityAct = -999.0
            angleAct = -999.0
        
        #rospy.loginfo("Received linear velocity: , angle: {}".format(angleAct))
        
        # Create a Twist message
        vel_msg = Twist()
        vel_msg.linear.x = float(velocityAct) * wheelRadius * 0.105  # Set linear velocity to 0.5 m/s
        vel_msg.angular.z = float(angleAct)  # Set angular velocity to 0.1 rad/s

        # Publish the Twist message
        actual_pub.publish(vel_msg)
        #rospy.sleep(0.5)

if __name__ == '__main__':
    try:
        desired_subscriber()
        actual_publisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass