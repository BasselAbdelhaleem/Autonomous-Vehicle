#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import math
import time

# Initialize global variables
x = 0.0
y = 0.0
theta = 0.0  # Orientation in radians
velocityAct = 0.0
angleAct = 0.0
ts = time.time()

def actual_callback(msg):
    global velocityAct, angleAct
    # Callback function to handle incoming velocity messages
    velocityAct = msg.linear.x
    angleAct = msg.angular.z

def localization_node():
    global x, y, theta, ts

    rospy.init_node('localization', anonymous=True)
    
    # Subscribe to the '/actual' topic which publishes velocity commands
    rospy.Subscriber('actual', Twist, actual_callback)
    
    # Publisher to publish the robot's pose
    actualPose_pub = rospy.Publisher('actualPose', Twist, queue_size=1)
    
    # Set the loop rate (in Hz)
    rate = rospy.Rate(100)  # 100 Hz

    while not rospy.is_shutdown():
        tsNew = time.time()
        dt = tsNew - ts
        ts = tsNew
        
        # Update the robot's pose
        delta_x = velocityAct * dt * math.cos(theta)
        delta_y = velocityAct * dt * math.sin(theta)
        delta_theta = angleAct * dt
        
        x += delta_x
        y += delta_y
        theta += delta_theta
        
        # Normalize theta to the range [-pi, pi]
        theta = (theta + math.pi) % (2 * math.pi) - math.pi
        
        # Create and publish the Pose message
        Twist_msg = Twist()
        Twist_msg.linear.x = x
        Twist_msg.linear.y = y
        Twist_msg.angular.z = theta
        
        actualPose_pub.publish(Twist_msg)
        
        rate.sleep()

if __name__ == '__main__':
    try:
        localization_node()
    except rospy.ROSInterruptException:
        pass


