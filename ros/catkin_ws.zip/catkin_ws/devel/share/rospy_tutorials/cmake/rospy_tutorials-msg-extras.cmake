set(rospy_tutorials_MESSAGE_FILES "/home/BasselKhaled/catkin_ws/src/ros_tutorials/rospy_tutorials/msg/Floats.msg;/home/BasselKhaled/catkin_ws/src/ros_tutorials/rospy_tutorials/msg/HeaderString.msg")
set(rospy_tutorials_SERVICE_FILES "/home/BasselKhaled/catkin_ws/src/ros_tutorials/rospy_tutorials/srv/AddTwoInts.srv;/home/BasselKhaled/catkin_ws/src/ros_tutorials/rospy_tutorials/srv/BadTwoInts.srv")
