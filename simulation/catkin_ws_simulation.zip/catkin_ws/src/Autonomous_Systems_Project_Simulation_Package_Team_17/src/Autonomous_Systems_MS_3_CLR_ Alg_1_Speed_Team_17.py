#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from geometry_msgs.msg import TwistStamped
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from nav_msgs.msg import Odometry
from pynput import keyboard
import numpy as np

desSpeed=0.0
curSpeed=0.0
pGain=5
iGain=9*(10**-8)
dGain=0
error=0
prevError=0
iError=0
dError=0

def drive_forward(throttle):
 if not rospy.is_shutdown():
  pubGear.publish(0)
  pubDriving.publish(throttle)
  rate.sleep()	
 	
def drive_reverse(throttle):
 if not rospy.is_shutdown():
  pubGear.publish(1)
  pubDriving.publish(throttle)
  rate.sleep()	
 

def callback_speed(msg):
 global curSpeed
 curSpeed=msg.twist.linear.x
 
def callback_desSpeed(msg):
 global desSpeed
 desSpeed=msg.data
 

rospy.init_node('Speed_Control', anonymous=True)

pubDriving = rospy.Publisher('throttle_cmd', Float64, queue_size=10)
pubGear = rospy.Publisher('gear_cmd', UInt8, queue_size=10)

subSpeed=rospy.Subscriber('twist',TwistStamped,callback_speed)


subDesSpeed=rospy.Subscriber('/APF_Des_vel',Float64,callback_desSpeed)
rate = rospy.Rate(100)

Total_time = 500000 #total time of simulation
Ts = 0.1 #sampling time
Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps
    
for t in Time:
 error=desSpeed-curSpeed
 iError+=(prevError+error)*t/2
 if t>0:
  dError=(curSpeed-prevError)/t
 else:
  dError=0 

 throttle=pGain*error+iGain*iError+dError

 if(desSpeed>0):
  if(throttle>1):
   throttle=1
  if(throttle<0):
   throttle=0
  drive_forward(throttle)
 if(desSpeed<0):
  if(throttle<-1):
   throttle=-1
  if(throttle>0):
   throttle=0
  drive_reverse(-1*throttle)
 rate.sleep()
  
 prevError=error
 #print("Desired Speed:"+str(desSpeed)+" Speed:"+str(curSpeed)+" throttle:"+str(throttle))
	


 
 

 
	
