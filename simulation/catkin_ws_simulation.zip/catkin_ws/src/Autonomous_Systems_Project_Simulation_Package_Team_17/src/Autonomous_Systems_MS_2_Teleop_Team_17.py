#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from geometry_msgs.msg import TwistStamped
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from nav_msgs.msg import Odometry
from pynput import keyboard
import numpy as np

speed=0
xPos=0
yPos=0
zAngle=0
steeringAngle=0

def drive_forward():
 if not rospy.is_shutdown():
  pubGear.publish(0)
  pubDriving.publish(driving)
  rate.sleep()	
 	
def drive_reverse():
 if not rospy.is_shutdown():
  pubGear.publish(1)
  pubDriving.publish(driving)
  rate.sleep()	
 
def steer_left():
 if not rospy.is_shutdown():
  pubSteering.publish(steering)
  rate.sleep()	

def steer_right():
 if not rospy.is_shutdown():
  pubSteering.publish(-1*steering)
  rate.sleep()	

def steer_center():
 if not rospy.is_shutdown():
  pubSteering.publish(0)
  rate.sleep()	

def callback_pose(msg):
 global xPos
 global yPos
 global zAngle
 xPos=msg.pose.pose.position.x
 yPos=msg.pose.pose.position.y
 zAngle=msg.pose.pose.orientation.z
 
def callback_steering(msg):
 global steeringAngle
 steeringAngle=msg.data

def callback_speed(msg):
 global speed
 speed=msg.twist.linear.x
 

rospy.init_node('Teleop', anonymous=True)

pubDriving = rospy.Publisher('throttle_cmd', Float64, queue_size=10)
pubSteering = rospy.Publisher('steering_cmd', Float64, queue_size=10)
pubGear = rospy.Publisher('gear_cmd', UInt8, queue_size=10)

subPosOri = rospy.Subscriber('odom', Odometry, callback_pose)
subSteer=rospy.Subscriber('steering_state',Float64,callback_steering)
subSpeed=rospy.Subscriber('twist',TwistStamped,callback_speed)

driving=rospy.get_param('~driving')
steering=rospy.get_param('~steering')
rate = rospy.Rate(100)

Total_time = 50 #total time of simulation
Ts = 0.1 #sampling time
Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps


def on_press(key):
  if key == keyboard.Key.up:
      drive_forward()
  if key == keyboard.Key.down:
      drive_reverse()
  if key == keyboard.Key.left:
      steer_left()
  if key == keyboard.Key.right:
      steer_right()
  if key == keyboard.Key.esc:
      listener.stop()
 

def on_release(key):
 steer_center()
  

listener = keyboard.Listener(on_press=on_press,on_release=on_release)
listener.start()
    
while True:
 print("Speed:"+str(speed)+" Steering Angle:"+str(steeringAngle)+" Position X:"+str(xPos)+" Position Y:"+str(yPos)+"Position Z:"+str(zAngle))
	


 
 

 
	
