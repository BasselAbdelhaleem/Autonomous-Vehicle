#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist,Pose
from geometry_msgs.msg import TwistStamped
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from nav_msgs.msg import Odometry
from pynput import keyboard
import math
import numpy as np


stop=False
desX=0.1
desY=0.1
xPosFil=0
yPosFil=0
yawFil=0
quaternion0Fil=0
quaternion1Fil=0
quaternion2Fil=0
quaternion3Fil=0
xPos=0
yPos=0
desYaw=0
desVel=10
yaw=0
desYaw=0
omegaZ=0
prevPoint=[0,0]
desPoint=[0,0]
curPose=[0,0]
quaternion0 =0
quaternion1 =0
quaternion2 =0
quaternion3 =0
curSteeringAngle=0
curSpeed=0.1
carLength=2.65
K=1500

def quaternion_to_euler(x, y, z, w):
 t0 = +2.0 * (w * x + y * z)
 t1 = +1.0 - 2.0 * (x * x + y * y)
 roll = math.atan2(t0, t1)
 t2 = +2.0 * (w * y - z * x)
 t2 = +1.0 if t2 > +1.0 else t2
 t2 = -1.0 if t2 < -1.0 else t2
 pitch = math.asin(t2)
 t3 = +2.0 * (w * z + x * y)
 t4 = +1.0 - 2.0 * (y * y + z * z)
 yaw = math.atan2(t3, t4)
 return [yaw, pitch, roll]


def steer(angle):
 if not rospy.is_shutdown():
  pubSteering.publish(angle)
  rate.sleep()	
  
def callback_pose(msg):
 global xPos
 global yPos
 global yaw
 global quaternion0
 global quaternion1
 global quaternion2
 global quaternion3
 xPos=round(msg.pose.pose.position.x,3)
 yPos=round(msg.pose.pose.position.y,3)
 [yaw,_,_]=quaternion_to_euler(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,msg.pose.pose.orientation.z,msg.pose.pose.orientation.w)
 yaw=round(yaw,3)


def callback_speed(msg):
 global curSpeed
 global omegaZ
 curSpeed=round(msg.twist.linear.x,3)
 omegaZ=round(msg.twist.angular.z,3)
 
def callback_steering(msg):
 global curSteeringAngle
 curSteeringAngle=round(msg.data,3)
 
def callback_desiredPose(msg):
 global desX
 global desY
 global desYaw
 desX=msg.position.x
 desY=msg.position.y 


rospy.init_node('Lateral_Control', anonymous=True)


subPosOri = rospy.Subscriber('odom', Odometry, callback_pose)
subSpeed=rospy.Subscriber('twist',TwistStamped,callback_speed)
subSteer=rospy.Subscriber('steering_state',Float64,callback_steering)
subDesPose=rospy.Subscriber('/APF_Des_Pos',Pose,callback_desiredPose)

pubSteering = rospy.Publisher('steering_cmd', Float64, queue_size=10)


rate = rospy.Rate(100)

Total_time = 50000 #total time of simulation
Ts = 0.1 #sampling time
Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps
    
for t in Time:
 desPoint=[desX,desY]
 curPose=[xPos,yPos]
 e_numerator = (desPoint[0]-prevPoint[0]) * (prevPoint[1]-curPose[1]) - (prevPoint[0]-curPose[0]) * (desPoint[1]-prevPoint[1])
 e_denominator = math.sqrt((desPoint[0]-prevPoint[0])**2 + (desPoint[1]-prevPoint[1])**2)
 if (e_denominator!=0):
  e = e_numerator / e_denominator
 else:
  e=0

 desYaw=math.atan2(desPoint[1]-prevPoint[1],desPoint[0]-prevPoint[0])
 errorYaw=desYaw-yaw
 lD=K*curSpeed

 
 
 if abs(curSpeed)>0:
  steeringAngle=round(errorYaw+np.arctan((K*e)/(curSpeed)),3)
  desstr=steeringAngle
 if(steeringAngle>3.14/6):
  steeringAngle=3.14/6
 if(steeringAngle<-3.14/6):
  steeringAngle=-3.14/6
 steeringAngle*=17.3
 steer(steeringAngle)
 prevPoint=curPose
 print("Act X:"+str(xPos)+" filtered X :"+str(xPosFil)+" Act Y:"+str(yPos)+" filterd Y:"+str(yPosFil)+" Act Z Angle="+str(yaw)+" filtered Z Angle="+str(yawFil))
	
	
