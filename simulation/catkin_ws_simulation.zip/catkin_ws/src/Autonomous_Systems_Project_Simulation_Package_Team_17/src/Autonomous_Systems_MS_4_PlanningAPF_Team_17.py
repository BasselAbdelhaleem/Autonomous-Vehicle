#!/usr/bin/env python

#########################################################################################################
#Import the required libraries:
import rospy
from geometry_msgs.msg import Twist,Pose
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import numpy as np
import math
import sympy as sym
from sympy import *

########################
#Initialize ROS Node
rospy.init_node('Path_Planning_APF', anonymous=True) #Identify ROS Node

pub1 = rospy.Publisher('/APF_Des_Pos', Pose, queue_size=10) #Identify the publisher "pub1" to publish on topic "/APF_Des_Pos" to send message of type "Pose"
pub2 = rospy.Publisher('/APF_Des_vel', Float64, queue_size=10)
Des_Pos_msg = Pose() #Identify msg variable of data type Twist
rate = rospy.Rate(100) # rate of publishing msg 10hz

xPos=0
yPos=0
yaw=0
Rob_pos=[0,0,0]
Rob_vel=[0,0]
curSpeed=0.0001
desVel=0
omegaZ=0
flag_cont=0
Rob_pos_0 = Rob_pos
Roc_vel_0 = Rob_vel

Goal_Pos = [rospy.get_param("~x_Goal"),rospy.get_param("~y_Goal")]
Obs_Pos = [rospy.get_param("~x_Obs"),rospy.get_param("~y_Obs")]
Obs1_Pos = [rospy.get_param("~x_Obs1"),rospy.get_param("~y_Obs1")]
APF_Param = [rospy.get_param("~K_att"),rospy.get_param("~K_rep"),rospy.get_param("~q_star")] #[K_att,K_rep,q_star]

x_rob = symbols('x_rob')
y_rob = symbols('y_rob')
x_goal = symbols('x_goal')
y_goal = symbols('y_goal')
x_obs = symbols('x_obs')
y_obs = symbols('y_obs')
x_obs1 = symbols('x_obs1')
y_obs1 = symbols('y_obs1')

#Attraction Forces Equations
Fx_att = -APF_Param[0]*(x_rob-x_goal)
Fy_att = -APF_Param[0]*(y_rob-y_goal)
#Repulsion Forces Equations
d_obs = sqrt((x_rob-x_obs)**2+(y_rob-y_obs)**2)
d_obs1 = sqrt((x_rob-x_obs1)**2+(y_rob-y_obs1)**2)
Fx_rep = -APF_Param[1]*((1/d_obs)-(1/APF_Param[2]))*(-(x_rob-x_obs)/(d_obs**3))-APF_Param[1]*((1/d_obs1)-(1/APF_Param[2]))*(-(x_rob-x_obs1)/(d_obs1**3))
Fy_rep = -APF_Param[1]*((1/d_obs)-(1/APF_Param[2]))*(-(y_rob-y_obs)/(d_obs**3))-APF_Param[1]*((1/d_obs1)-(1/APF_Param[2]))*(-(y_rob-y_obs1)/(d_obs1**3))


x_p = Rob_pos_0[0]
y_p = Rob_pos_0[1]
vel_p_x = Roc_vel_0[0]*cos(Rob_pos_0[2])
vel_p_y = Roc_vel_0[0]*sin(Rob_pos_0[2])

 
def callback_speed(msg):
 global curSpeed
 global omegaZ
 curSpeed=round(msg.twist.linear.x,3)
 omegaZ=round(msg.twist.angular.z,3)
 
 
def euler_to_quaternion(yaw, pitch, roll):
 x = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
 y = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
 z = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
 w = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
 return [x, y, z, w]
#######################################################################

#######################################################################
def quaternion_to_euler(x, y, z, w):
 t0 = +2.0 * (w * x + y * z)
 t1 = +1.0 - 2.0 * (x * x + y * y)
 roll = math.atan2(t0, t1)
 t2 = +2.0 * (w * y - z * x)
 t2 = +1.0 if t2 > +1.0 else t2
 t2 = -1.0 if t2 < -1.0 else t2
 pitch = math.asin(t2)
 t3 = +2.0 * (w * z + x * y)
 t4 = +1.0 - 2.0 * (y * y + z * z)
 yaw = math.atan2(t3, t4)
 return [yaw, pitch, roll]

def callback_pose(msg):
 global xPos
 global yPos
 global yaw
 global flag_cont
 flag_cont=1
 xPos=round(msg.pose.pose.position.x,3)
 yPos=round(msg.pose.pose.position.y,3)
 [yaw,_,_]=quaternion_to_euler(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,msg.pose.pose.orientation.z,msg.pose.pose.orientation.w)
 


def APF_Fn(Rob_pos,Goal_pos,Obs_pos,Obs1_pos,APF_Param):
 global Fx_att
 global Fy_att
 global d_obs
 global Fx_rep
 global Fy_rep

 Fx_att_val = Fx_att.subs([(x_rob,Rob_pos[0]),(x_goal,Goal_pos[0])])
 Fy_att_val = Fy_att.subs([(y_rob,Rob_pos[1]),(y_goal,Goal_pos[1])])
 d_obs_val = d_obs.subs([(x_rob,Rob_pos[0]),(y_rob,Rob_pos[1]),(x_obs,Obs_pos[0]),(y_obs,Obs_pos[1])])
 d_obs1_val = d_obs1.subs([(x_rob,Rob_pos[0]),(y_rob,Rob_pos[1]),(x_obs1,Obs1_pos[0]),(y_obs1,Obs1_pos[1])])
 if d_obs_val<APF_Param[2] or d_obs1_val<APF_Param[2] :
  Fx_rep_val = Fx_rep.subs([(x_rob,Rob_pos[0]),(y_rob,Rob_pos[1]),(x_obs,Obs_pos[0]),(y_obs,Obs_pos[1]),(d_obs,d_obs_val),(x_obs1,Obs1_pos[0]),(y_obs1,Obs_pos[1]),(d_obs1,d_obs1_val)])
  Fy_rep_val = Fy_rep.subs([(x_rob,Rob_pos[0]),(y_rob,Rob_pos[1]),(x_obs,Obs_pos[0]),(y_obs,Obs_pos[1]),(d_obs,d_obs_val),(x_obs1,Obs1_pos[0]),(y_obs1,Obs1_pos[1]),(d_obs1,d_obs1_val)])
  
 else:
  Fx_rep_val = 0
  Fy_rep_val = 0 
 Fx_net_val = Fx_att_val + Fx_rep_val
 Fy_net_val = Fy_att_val + Fy_rep_val
 F_xy_net = [Fx_net_val,Fy_net_val]
 return F_xy_net
  
  
subPosOri = rospy.Subscriber('odom', Odometry, callback_pose)

tau = rospy.get_param("~tau") #Sampling Time
rob_mass = rospy.get_param("~rob_mass") #Robot Mass (Turtlebot 3 Waffle_pi)

Total_time = 50000 #total time of simulation
Ts = 0.1 #sampling time
Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps

for t in Time:
 if flag_cont == 1:
#Get Robot Current Position and Velocity
  Rob_pos = [xPos,yPos,yaw]
  Rob_vel = [curSpeed,omegaZ]
#Implement Artificial Potential Field
  F_xy_net = APF_Fn(Rob_pos,Goal_Pos,Obs_Pos,Obs1_Pos,APF_Param)
  F_net = float(sqrt(F_xy_net[0]**2+F_xy_net[1]**2))
  F_net_direct = float(atan2(F_xy_net[1],F_xy_net[0]))
#Calculate the desired robot position from the APF
  vel_c_x = vel_p_x + (F_xy_net[0]/rob_mass)*tau
  vel_c_y = vel_p_y + (F_xy_net[1]/rob_mass)*tau
  desVel=sqrt(vel_c_x**2+vel_c_y**2)
  x_des = x_p + vel_c_x*tau
  y_des = y_p + vel_c_y*tau
  theta_des = F_net_direct
  Rob_pos_des = [x_des,y_des,theta_des]
#Update the previous robot states for the next iteration
  vel_p_x = Rob_vel[0]*cos(Rob_pos[2])
  vel_p_y = Rob_vel[0]*sin(Rob_pos[2])
  x_p = Rob_pos[0]
  y_p = Rob_pos[1]
  flag_cont = 0
 else:
  Rob_pos_des = Rob_pos
 Des_Pos_msg.position.x = Rob_pos_des[0]
 Des_Pos_msg.position.y = Rob_pos_des[1]
 Des_Pos_msg.position.z = 0
 [qx_des, qy_des, qz_des, qw_des] = euler_to_quaternion(Rob_pos_des[2], 0, 0)
 Des_Pos_msg.orientation.x = qx_des
 Des_Pos_msg.orientation.y = qy_des
 Des_Pos_msg.orientation.z = qz_des
 Des_Pos_msg.orientation.w = qw_des
 pub1.publish(Des_Pos_msg)	#Publish msg
 pub2.publish(desVel)
 rate.sleep()		


