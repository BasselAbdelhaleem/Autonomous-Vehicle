#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from geometry_msgs.msg import TwistStamped
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry
import numpy as np



def callback_pose(msg):
 print(msg.pose)

def callback_steering(msg):
 print("Steering Angle: "+ str(msg.data))

def callback_speed(msg):
 print("Speed: "+ str(msg))

rospy.init_node('OLR', anonymous=True)


pubDriving = rospy.Publisher('throttle_cmd', Float64, queue_size=10)
pubSteering = rospy.Publisher('steering_cmd', Float64, queue_size=10)
subPosOri = rospy.Subscriber('odom', Odometry, callback_pose)
subSteer=rospy.Subscriber('steering_state',Float64,callback_steering)
subSpeed=rospy.Subscriber('twist',TwistStamped,callback_speed)

driving=rospy.get_param('~driving')
steering=rospy.get_param('~steering')
rate = rospy.Rate(100)

Total_time = 10000 #total time of simulation
Ts = 0.1 #sampling time
Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps



for t in Time:
 	
    #ROS Code Publisher
	if not rospy.is_shutdown(): #To allow terminating node from terminal (ctrl_c)
		pubDriving.publish(driving)	#publish msg
		pubSteering.publish(steering)
		rate.sleep()			#sleep with rate

	
