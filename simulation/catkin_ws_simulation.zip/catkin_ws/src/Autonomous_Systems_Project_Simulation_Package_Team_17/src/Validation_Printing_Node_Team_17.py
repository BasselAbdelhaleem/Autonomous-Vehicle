#!/usr/bin/env python

import rospy

rospy.init_node('Hello_World')

print("Hello world Hal ros sha8al?")
