#!/usr/bin/env python
# A basic python code to subscribe from the turtlebot its position and orientation through odometery sensor
### Libraries to be imported
import rospy #library to connect ROS with python
import matplotlib.pyplot as plt #library used for plotting
import numpy as np #library used for mathematical operations
import math
import time
import tf #library used for states transformation from Quaternian to Euler and vice versa
from nav_msgs.msg import Odometry #import msg data type "Odometry" from nav_msgs dependency to be subscribed
from geometry_msgs.msg import Twist, Pose #import msg data type "Twist" and "Pose" from geometry_msgs dependency to
import rospy
from geometry_msgs.msg import Twist,Pose
from geometry_msgs.msg import TwistStamped
from std_msgs.msg import Float64
from std_msgs.msg import UInt8
from nav_msgs.msg import Odometry
from pynput import keyboard
import math
import numpy as np

### Initialize ROS Node
rospy.init_node('Kalman_Filter', anonymous = True) #Identify Ros Node.
## ROS Publisher Code

Xfiltered=[[0],[0],[0]]
Xfiltered=np.array(Xfiltered)
Pfiltered=[[0,0,0],[0,0,0],[0,0,0]]
Pfiltered=np.array(Pfiltered)
Z=[[0],[0],[0]]
Z=np.array(Z)
U=[[0],[0]]
U=np.array(U)
xPos=0
yPos=0
yaw=0
curSpeed=0
omegaZ=0
quaternion0=0
quaternion1=0
quaternion2=0
quaternion3=0
carPoseYaw=0



rate=rospy.Rate(100) # rate of publishing msg 10hz

## Method used to transform from Euler coordinates to Quaternion coordinates
def euler_to_quaternion(yaw, pitch, roll):
    x = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    y = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
    z = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
    w = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    return [x, y, z, w]
    
    
## Method used to transform from Quaternion coordinates to Euler coordinates
def quaternion_to_euler(x, y, z, w):
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch = math.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(t3, t4)
    return [yaw, pitch, roll]




def callback_speed(msg):
 global curSpeed
 global omegaZ
 curSpeed=round(msg.twist.linear.x,3)
 omegaZ=round(msg.twist.angular.z,3)
 
 
 
def callback_pose(msg):
 global xPos
 global yPos
 global yaw
 global quaternion0
 global quaternion1
 global quaternion2
 global quaternion3
 xPos=round(msg.pose.pose.position.x,3)+np.random.normal(0,.1,2)
 yPos=round(msg.pose.pose.position.y,3)+np.random.normal(0,0.1,2)
 [yaw,_,_]=quaternion_to_euler(msg.pose.pose.orientation.x,msg.pose.pose.orientation.y,msg.pose.pose.orientation.z,msg.pose.pose.orientation.w)
 yaw=yaw+np.random.normal(0,0.1,1)


subPosOri = rospy.Subscriber('odom', Odometry, callback_pose)
subSpeed=rospy.Subscriber('twist',TwistStamped,callback_speed)

pubFilteredPos= rospy.Publisher('odomKal', Odometry, queue_size=10)


carPose=Odometry()


        
        
        
        




## Prediction stage in Kalman filter
def kf_prediction(Xprev, Pprev, A, Q, B, U):
    Xpredicted=np.matmul(A, Xprev)+np.dot (B, U) ## Predicted state vector
    Ppredicted=np.matmul (A, np.matmul(Pprev, np.transpose(A))) + Q ## Predicted error co-variance matrix
    return [Xpredicted, Ppredicted]
## Correction stage in Kalman filter
def kf_correction(Xpredicted, Ppredicted, C, Z, R):
    CTrans=np.transpose(C)
    num=np.matmul(Ppredicted, CTrans) ##Numerature of Kalman gain equation
    den1=np.matmul(C, Ppredicted) # #CMatrix PMatrix
    den2=np.matmul(den1, CTrans)+ R ##CMatrix PMatrix CMatrix^T + R
    den=np.matrix(den2) ## Place denemrature in matrix form
    deninv=den.getI() ## (CMatrix PMatrix CMatrix^T + R) Inverse
    KGain=np.matmul (num, deninv) # # Calculate the Kalman gain
    #print("KG" + str(KGain))
    Xfiltered=Xpredicted + np.matmul (KGain, (Z-np.matmul (C, Xpredicted))) ## Estimated updated state vector
    Pfiltered=Ppredicted - np.matmul (KGain, np.matmul (C, Ppredicted)) ##Estimated updated error co-variance matrix
    return [Xfiltered, Pfiltered]
    
    
    
    ## Initialization:
P = [[100,0,0], [0,100,0], [0,0,1]] ## Error co-variance matrix P (3x3)
Q=[[0.01,0,0], [0,0.01,0], [0,0,0.01]] ## Process noise matrix Q (3x3)
R = [[0.1],[0.1],[0.1]] ##Measurement noise matrix R (1x1)
# # Control input matrix U (2x1)
X= [[0], [0], [0]] ## Initial state X (3x1)
A = [[1,0,0],[0,1,0],[0,0,1]] ## State transition matrix A (3x3)
B=[[0.1,0], [0,0], [0,0.1]] ## Input matrix B (3x2)
C = [[1,0,0],[0,1,0],[0,0,1]] ## Measurement matrix C (1x3)

P=np.array(P)
Q=np.array(Q)
R=np.array(R)
X=np.array(X)
A=np.array(A)
B=np.array(B)
C=np.array(C)

Total_time = 500000 #total time of simulation
Ts = 0.1 #sampling time
Time = np.arange(0,Total_time + Ts,Ts)  #define the array of time steps
    
for t in Time:
       Z = [[xPos],[yPos],[yaw]] # # Set the sensor reading for the x position of the robot
       X = Xfiltered # # Update the states with the filtered states
       P = Pfiltered ##Update the error co-variance matrix
       U=[[curSpeed],[omegaZ]]
       [Xpredicted, Ppredicted] = kf_prediction (X, P, A, Q, B, U) ## Get the predicted states
       [Xfiltered, Pfiltered] = kf_correction (Xpredicted, Ppredicted, C, Z, R) # # Get the corrected states
      
       
       xPosFiltered=round(np.mean(Xfiltered.item(0)),3)
       yPosFiltered=round(np.mean(Xfiltered.item(1)),3)
       yawFiltered=round(np.mean(Xfiltered.item(2)),3)
       
       
       carPose.pose.pose.position.x=xPosFiltered
       carPose.pose.pose.position.y=yPosFiltered
       carPoseYaw=Xfiltered.item(2)
       [carPose.pose.pose.orientation.x,carPose.pose.pose.orientation.y,carPose.pose.pose.orientation.z,carPose.pose.pose.orientation.w]=euler_to_quaternion(yawFiltered, 0, 0)
       pubFilteredPos.publish(carPose)
       
       rate.sleep()

